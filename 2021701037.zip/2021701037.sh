#!/bin/bash
#echo $1
python3 Assignment.py "$1"

